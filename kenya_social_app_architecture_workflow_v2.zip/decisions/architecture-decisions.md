# Architecture Decisions

## ADR-001: Two clients, one backend
**Decision:** React Native + Expo for Android, Next.js for PWA, shared Supabase backend.  
**Reason:** Native Android UX and store distribution are supported without sacrificing a low-friction web experience.

## ADR-002: Managed authentication
**Decision:** Use a managed identity provider rather than implementing password/session management from scratch.  
**Reason:** Reduces avoidable authentication risk and maintenance burden.

## ADR-003: PostgreSQL as source of truth
**Decision:** Store relationships, permissions, content, payment records and entitlements in PostgreSQL.  
**Reason:** Relational constraints and transactions fit social relationships and payment state.

## ADR-004: Dating is opt-in
**Decision:** Separate dating preferences and discovery eligibility from friendship and social features.  
**Reason:** Avoids unwanted dating exposure and supports clearer consent.

## ADR-005: Privacy-first location
**Decision:** Broad city/town labels only by default; no public exact coordinates or background location in MVP.  
**Reason:** Reduces stalking and privacy risks.

## ADR-006: Payments are server-verified
**Decision:** Only trusted server callbacks/reconciliation grant premium.  
**Reason:** Client success screens can be spoofed and callbacks can be duplicated.

## ADR-007: Brand remains provisional
**Decision:** Use Mingleza as a working codename only until trademark, domain and app-store checks are complete.  
**Reason:** Avoid costly rebranding and legal conflict after launch.

## Decision: Global Explore Map

**Decision:** use a third-party map SDK for map rendering/place search, and keep discovery/matching logic in the app backend using Supabase/PostgreSQL/PostGIS. Compare Google Maps Platform and Mapbox before final selection. Show privacy-safe approximate locations only to members who have enabled/consented to map discovery. Keep precise location restricted; do not expose it in client queries. Use presence freshness, block filtering, rate limits, result caps, and anti-enumeration safeguards.
