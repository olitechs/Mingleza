# Kenya-first Social App — Architecture & Workflow Blueprint

**Working codename:** Mingleza (not cleared for trademark/domain use)  
**Product:** Adults-only (18+) social networking app for friendship, opt-in dating, and general social networking.  
**Launch:** Kenya-first, Android app + installable website (PWA), with future Africa/Europe expansion.

> This ZIP contains the product architecture and workflow documentation, not a complete runnable application or production source code.

## Documents
- `docs/01-product-requirements.md` — MVP scope and non-goals
- `docs/02-screen-flows.md` — screen-by-screen journeys
- `docs/03-system-architecture.md` — application architecture and stack
- `docs/04-database-schema.md` — proposed database tables and constraints
- `docs/05-security-privacy.md` — security, privacy and moderation requirements
- `docs/06-monetization-payments.md` — monetization and payment workflow
- `docs/07-development-roadmap.md` — implementation phases and acceptance criteria
- `docs/08-launch-operations.md` — beta launch, metrics and operations
- `diagrams/system-architecture.mmd` — Mermaid architecture diagram
- `diagrams/user-journey.mmd` — Mermaid onboarding and connection journey
- `diagrams/payment-flow.mmd` — Mermaid payment workflow
- `checklists/mvp-checklist.md` — feature checklist
- `checklists/release-checklist.md` — pre-launch checks
- `decisions/architecture-decisions.md` — key technology and product decisions

## Recommended stack
- Android: React Native + Expo + TypeScript
- Website/PWA: Next.js + TypeScript
- Backend: Supabase Auth, PostgreSQL, Storage, Realtime where appropriate
- Trusted server operations: server-side API routes / Edge Functions
- Payments: M-Pesa via Safaricom Daraja for eligible Kenya payment flows; verify Google Play billing requirements for in-app digital goods
- Repository: monorepo with shared types and validation

## Suggested repository layout
```text
mingleza/
├── apps/
│   ├── android/
│   ├── web/
│   └── admin/            # can begin as protected section of web app
├── packages/
│   ├── types/
│   ├── validation/
│   └── config/
├── supabase/
│   ├── migrations/
│   ├── functions/
│   └── seed.sql
├── docs/
├── diagrams/
└── README.md
```

## Important caveat
The brand name is provisional. Complete KIPI, TMview/international trademark, domain, app-store and similar-name checks before investing in final branding. This blueprint does not constitute legal advice or a completed compliance review.


## Global Explore Map (added in v2)

The app plan now includes an Explore Map where users can search any supported town, city, or country and discover eligible online members at approximate locations. The map provider renders maps and supports place search; Supabase/PostgreSQL/PostGIS and trusted backend logic handle presence, eligibility, geographic filtering, and privacy.

Read:
- `docs/09-explore-map-architecture.md`
- `diagrams/explore-map-architecture.mmd`
- `diagrams/explore-map-flow.mmd`
- `checklists/explore-map-checklist.md`

Privacy decision: only users who have been informed and have enabled/consented to map discovery appear. The client never receives stored precise GPS coordinates. The map is a planning/documentation feature; these files are not runnable app source code and do not represent implemented endpoints.
