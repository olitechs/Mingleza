# Release Checklist

## Security
- [ ] No service-role or provider secrets in client bundles
- [ ] RLS enabled and tested on all client-accessible tables
- [ ] Admin MFA and least privilege enabled
- [ ] Rate limits enabled
- [ ] Upload validation enabled
- [ ] No private message content in analytics or logs
- [ ] Dependency and secret scan completed

## Privacy and legal
- [ ] Privacy policy and terms published
- [ ] Data collection and retention documented
- [ ] Account deletion workflow tested
- [ ] Data export/request workflow documented
- [ ] ODPC and launch-country obligations reviewed
- [ ] Cross-border transfer considerations reviewed
- [ ] Age-assurance and underage escalation reviewed

## Social safety
- [ ] Block, report, mute and unmatch tested
- [ ] Moderator queue staffed
- [ ] Community guidelines published
- [ ] Appeals/support channel working
- [ ] Anonymous-note limitations explained
- [ ] Abuse response process rehearsed

## Payments
- [ ] Provider sandbox tests passed
- [ ] Duplicate callbacks do not duplicate entitlements
- [ ] Invalid callbacks rejected
- [ ] Reversal/refund behavior tested
- [ ] Payment records reconcile with provider
- [ ] Play billing requirements checked for Android digital goods

## Reliability
- [ ] Production and staging are separate
- [ ] Backups configured and restore tested
- [ ] Error monitoring enabled
- [ ] Critical user flows tested on target Android devices
- [ ] PWA install, update and offline/error behavior tested
- [ ] Support and incident contacts documented
