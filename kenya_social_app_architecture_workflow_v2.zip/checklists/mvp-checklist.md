# MVP Checklist

## Product
- [ ] Name and brand clearance completed
- [ ] Adult-only positioning and age-assurance approach defined
- [ ] Friendship and dating modes separated
- [ ] Social feed and communities scoped
- [ ] Message request policy documented

## Accounts
- [ ] Registration and sign-in
- [ ] Profile setup and editing
- [ ] Interest selection
- [ ] Visibility and location controls
- [ ] Session revocation and account deletion

## Discovery and connection
- [ ] Friends discovery
- [ ] Dating discovery only for opted-in users
- [ ] Friendship requests and accepted connections
- [ ] Dating likes and mutual matches
- [ ] Block and unmatch enforcement

## Social and messaging
- [ ] Create and delete posts
- [ ] Comments
- [ ] Communities and membership
- [ ] Anonymous notes with documented limitations
- [ ] Private messaging
- [ ] Notifications with safe default content

## Safety
- [ ] Report users and content
- [ ] Moderator queue
- [ ] Audit log
- [ ] Rate limits and spam controls
- [ ] Age-related escalation process
- [ ] Privacy notice and community guidelines

## Payments
- [ ] Product/plan catalogue
- [ ] Sandbox checkout
- [ ] Verified provider callbacks
- [ ] Idempotency
- [ ] Payment reconciliation
- [ ] Entitlement expiry and cancellation
- [ ] Google Play billing review

## Quality
- [ ] RLS tests
- [ ] Android device testing
- [ ] Slow network and error states
- [ ] Accessibility review
- [ ] Monitoring and backup restore test

## Global Explore Map

- [ ] Search supported towns/cities/countries and navigate the map.
- [ ] Only show online, eligible members who enabled map discovery.
- [ ] Return approximate display locations only; never return precise GPS.
- [ ] Apply blocks, account/age eligibility, freshness, and rate limits.
- [ ] Provide manual location selection and visibility opt-out.
- [ ] Test privacy leakage, scraping resistance, and map-provider cost alerts.
