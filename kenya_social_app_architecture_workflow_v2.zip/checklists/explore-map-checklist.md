# Explore Map implementation checklist

## Product and UX
- [ ] Search by town, city, region, or country.
- [ ] Support map pan/zoom and bounded viewport queries.
- [ ] Tap marker to open a profile preview.
- [ ] Keep friendship and dating intent separate and explicit.
- [ ] Provide a clear map-visibility toggle and explanation.
- [ ] Allow manual place selection without GPS.
- [ ] Provide empty states, loading states, error states, and offline handling.

## Backend and data
- [ ] Enable PostGIS and create spatial indexes.
- [ ] Separate restricted location data from public profile data.
- [ ] Add presence freshness / session expiry logic.
- [ ] Add a trusted map discovery endpoint or Edge Function.
- [ ] Filter disabled visibility, stale/offline, blocked, suspended, and ineligible accounts.
- [ ] Return only a capped list of public map cards.
- [ ] Add pagination, bounds validation, rate limits, and anti-enumeration controls.
- [ ] Avoid high-frequency writes and unnecessary location history.

## Privacy and security
- [ ] Consent is informed and revocable.
- [ ] No precise coordinates are sent to other users.
- [ ] RLS and server authorization tests pass.
- [ ] Test blocks in both directions.
- [ ] Test location visibility off and account deletion.
- [ ] Test stale presence, logout, force-close, backgrounding, and lost connectivity.
- [ ] Review location permission wording and data retention.
- [ ] Add abuse reporting and moderation escalation paths.

## Provider and release
- [ ] Compare Google Maps and Mapbox for Android/web, place search, terms, and cost.
- [ ] Restrict public API keys by platform and allowed APIs.
- [ ] Configure usage quotas and billing alerts.
- [ ] Test performance with clustered markers and realistic data volumes.
- [ ] Monitor map loads, geocoding usage, query latency, and scraping attempts.
