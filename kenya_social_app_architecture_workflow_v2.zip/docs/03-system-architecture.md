# 03 — System Architecture

## High-level components
- Android client: React Native + Expo + TypeScript
- Web/PWA client: Next.js + TypeScript
- Shared backend: Supabase Auth, PostgreSQL, Storage and selected Realtime channels
- Trusted business logic: server-side API routes and/or Supabase Edge Functions
- Admin interface: protected area of web app initially
- Push notifications: platform notification provider with minimal sensitive payloads
- Payments: provider adapter layer, starting with supported M-Pesa flows

## Architecture rules
- All clients use the same canonical backend and data model.
- Client-side validation improves UX but never replaces server-side validation.
- Never embed service-role keys, payment secrets or webhook secrets in client bundles.
- Keep privileged actions behind trusted server functions.
- Apply RLS to all user-accessible tables and test both allowed and denied cases.
- Use signed, short-lived URLs for private media where appropriate.
- Realtime is an optimization; database authorization remains authoritative.
- Use migrations in version control; avoid undocumented manual schema edits.

## Suggested monorepo
apps/android — Expo app
apps/web — Next.js PWA and public pages
apps/admin — optional separate admin app; can initially live inside apps/web
packages/types — shared DTOs and domain types
packages/validation — shared validation schemas
packages/config — lint, TypeScript and environment conventions
supabase/migrations — versioned SQL migrations
supabase/functions — trusted operations and payment callbacks
supabase/seed.sql — development seed data

## Environment separation
- Local development: test users and fake payment responses
- Staging: separate Supabase project and payment sandbox
- Production: separate project, restricted secrets, backups and monitoring

## Example environment variables
Web public variables may include only publishable values:
- NEXT_PUBLIC_SUPABASE_URL
- NEXT_PUBLIC_SUPABASE_ANON_KEY (or publishable key, according to current Supabase setup)

Server-only secrets:
- SUPABASE_SERVICE_ROLE_KEY
- PAYMENT_PROVIDER_SECRET
- PAYMENT_CALLBACK_SECRET
- Any signing or email provider secrets

Do not commit `.env` files. Commit an `.env.example` with empty placeholders only.

## Key flows
- Authentication: client → managed Auth → session → RLS-protected database access
- Discovery: client → server query/RPC → filters for mode, visibility, blocks and account status
- Messaging: client → authorized server/database operation → message row → notification
- Payment: client → trusted server creates pending transaction → provider → signed/validated callback → idempotent reconciliation → entitlement

## Global Explore Map subsystem

Use a map SDK (evaluate Google Maps Platform vs Mapbox) for rendering and supported place search. Use Supabase Auth and a trusted API/Edge Function with PostgreSQL + PostGIS for map discovery. Presence is transient (Supabase Realtime Presence and/or backend heartbeat expiry). Keep precise location in a restricted table; return only coarse display locations and limited public profile cards. The API must enforce visibility consent, online freshness, age/account eligibility, blocks, query bounds, pagination, and rate limits. See `docs/09-explore-map-architecture.md` and the Explore Map diagrams.
