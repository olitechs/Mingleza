# 08 — Launch and Operations

## Beta launch
- Start with a limited cohort of consenting adult users.
- Seed a small number of genuine communities and interest categories.
- Provide clear community guidelines and a visible reporting flow.
- Have moderators available during beta hours.
- Collect feedback without exposing private conversations in analytics.

## Metrics
### Activation
- registration completion rate
- profile completion rate
- percentage choosing at least one intent
- time to first meaningful action

### Connection quality
- accepted friendship requests
- mutual dating matches
- conversations started after accepted connection/match
- repeat meaningful interactions per active user

### Retention
- day 1, day 7 and day 30 retention
- weekly active users
- notification opt-out and uninstall indicators where available

### Safety
- reports per 1,000 active users
- median report response time
- repeat-offender rate
- block rate and abuse-related account restrictions

### Revenue
- free-to-paid conversion
- paid renewal and churn
- revenue per paying user
- payment failure and reversal rates
- contribution margin after provider fees, infrastructure and moderation

## Launch sequence
1. Internal dogfooding.
2. Closed beta with a small adult cohort.
3. Fix critical UX, safety and reliability issues.
4. Expand across selected Kenyan towns.
5. Review retention and moderation capacity before marketing at scale.
6. Expand to additional countries only after local legal and operational review.

## Operations
- Define an incident response owner and contact channel.
- Monitor API errors, database health, payment callbacks and notification delivery.
- Set up backups and test restoration.
- Document account appeals, data requests, deletion and safety escalations.
- Review moderator access and logs regularly.
