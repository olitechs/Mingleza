# 06 — Monetization and Payments

## Proposed monetization sequence
### Launch
- Free baseline social experience
- Premium plan with additional discovery filters and customization
- Optional profile or post boost, clearly marked as promoted

### Later
- Sponsored local events and business pages
- Paid community tools
- Additional country-specific payment providers

Do not charge for block/report features or essential privacy controls. Avoid manipulative paywalls around safety.

## Test prices (not market-validated)
- Premium: KES 199–399/month
- One-time boost: KES 49–149
Prices should be tested with users and reviewed against fees, taxes and conversion.

## Payment state machine
created → pending → successful | failed | reversed

Only a trusted backend process can transition a payment into a verified successful state or grant entitlements.

## Payment workflow
1. Client selects product/plan.
2. Backend validates plan, amount, currency, user eligibility and idempotency key.
3. Backend creates a pending payment record.
4. Backend initiates provider checkout.
5. Provider sends callback to a server endpoint.
6. Server validates authenticity and provider reference; never trust client-supplied success.
7. Store event with unique provider event ID.
8. Reconcile payment idempotently.
9. Grant or renew entitlement only after verified success.
10. Handle delayed, duplicated, failed and reversed events.
11. Provide support/refund process and transaction history.

## Kenya
Investigate Safaricom Daraja for supported M-Pesa payment flows and test with the sandbox before production onboarding. Keep provider credentials server-side.

## Android digital goods
Before release, confirm current Google Play billing policy for digital subscriptions, boosts and other in-app digital features, including any applicable regional exceptions. Do not assume external checkout is permitted in every in-app context.

## Accounting and abuse controls
- Use integer minor units or exact decimal amounts, never floating point for money.
- Keep immutable provider references and payment event records.
- Reconcile provider reports regularly.
- Apply purchase limits and fraud checks.
- Do not store raw card credentials.
- Separate payment status from subscription entitlement status.
