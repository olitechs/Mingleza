# 04 — Database Schema Blueprint

This is a logical schema, not a production-ready SQL migration. Define UUID primary keys, foreign keys, indexes, constraints, deletion behavior and RLS policies during implementation.

## Identity and profile
### profiles
- user_id UUID PK/FK to auth user
- username TEXT UNIQUE NOT NULL
- display_name TEXT NOT NULL
- bio TEXT nullable
- birth_date DATE or minimal age-verification result (avoid retaining full DOB if not needed)
- country_code CHAR(2)
- preferred_language TEXT
- avatar_path TEXT nullable
- account_status TEXT: active, limited, suspended, deletion_pending
- created_at, updated_at TIMESTAMPTZ

### profile_preferences
- user_id UUID PK/FK
- friendship_enabled BOOLEAN
- dating_enabled BOOLEAN
- discovery_visibility TEXT
- profile_visibility TEXT
- location_label TEXT nullable
- notification_preferences JSONB with validated schema
- updated_at TIMESTAMPTZ

### interests
- id UUID PK
- slug TEXT UNIQUE
- label TEXT
- status TEXT

### user_interests
- user_id UUID FK
- interest_id UUID FK
- PRIMARY KEY(user_id, interest_id)

## Connections and dating
### connections
- id UUID PK
- requester_id UUID FK
- recipient_id UUID FK
- status TEXT: pending, accepted, rejected, cancelled
- created_at, updated_at
- constraint: requester_id != recipient_id
- add unique/partial indexes to prevent duplicate active requests

### likes
- id UUID PK
- sender_id UUID FK
- recipient_id UUID FK
- created_at
- constraint: sender_id != recipient_id
- unique(sender_id, recipient_id)

### matches
- id UUID PK
- user_a UUID FK
- user_b UUID FK
- status TEXT: active, unmatched
- created_at, unmatched_at
- store users in canonical order to enforce unique pair

## Social content
### posts
- id UUID PK
- author_id UUID FK (private internal reference)
- body TEXT
- visibility TEXT: public, community, followers if supported
- community_id UUID nullable
- anonymous_public BOOLEAN
- status TEXT: active, hidden, removed, under_review
- created_at, updated_at
- enforce body length and rate limits

### comments
- id UUID PK
- post_id UUID FK
- author_id UUID FK
- body TEXT
- status TEXT
- created_at

### communities
- id UUID PK
- name TEXT
- slug TEXT UNIQUE
- description TEXT
- visibility TEXT
- status TEXT
- created_at

### community_members
- community_id UUID FK
- user_id UUID FK
- role TEXT
- status TEXT
- joined_at
- PRIMARY KEY(community_id, user_id)

## Messaging
### conversations
- id UUID PK
- type TEXT: direct
- status TEXT
- created_at

### conversation_members
- conversation_id UUID FK
- user_id UUID FK
- joined_at
- PRIMARY KEY(conversation_id, user_id)

### messages
- id UUID PK
- conversation_id UUID FK
- sender_id UUID FK
- body TEXT or supported attachment metadata
- created_at
- edited_at nullable
- deleted_at nullable
- enforce sender membership in the conversation

## Safety
### blocks
- blocker_id UUID FK
- blocked_id UUID FK
- created_at
- PRIMARY KEY(blocker_id, blocked_id)
- constraint: blocker_id != blocked_id

### reports
- id UUID PK
- reporter_id UUID FK
- target_type TEXT
- target_id UUID
- reason_code TEXT
- description TEXT nullable
- status TEXT: open, reviewing, actioned, dismissed
- assigned_moderator UUID nullable
- created_at, resolved_at nullable

### moderation_actions
- id UUID PK
- moderator_id UUID FK
- target_user_id UUID nullable
- target_type TEXT
- target_id UUID nullable
- action TEXT
- reason TEXT
- created_at

### audit_logs
- id UUID PK
- actor_id UUID nullable
- action TEXT
- target_type TEXT
- target_id UUID nullable
- metadata JSONB with sensitive data excluded
- created_at

## Monetization
### plans
- id UUID PK
- code TEXT UNIQUE
- display_name TEXT
- price_minor_units BIGINT
- currency CHAR(3)
- billing_period TEXT
- active BOOLEAN

### subscriptions
- id UUID PK
- user_id UUID FK
- plan_id UUID FK
- status TEXT
- provider TEXT
- provider_reference TEXT nullable
- starts_at, expires_at TIMESTAMPTZ

### payments
- id UUID PK
- user_id UUID FK
- provider TEXT
- provider_reference TEXT UNIQUE
- amount_minor_units BIGINT
- currency CHAR(3)
- status TEXT: pending, successful, failed, reversed
- idempotency_key TEXT UNIQUE
- created_at, updated_at

### payment_events
- id UUID PK
- provider_event_id TEXT UNIQUE
- payment_id UUID FK
- event_type TEXT
- verified BOOLEAN
- received_at TIMESTAMPTZ
- minimal redacted payload JSONB

## Critical indexes and constraints
- username unique, normalized case-insensitively
- indexes for discovery filters, created_at, active status
- messages index on (conversation_id, created_at)
- reports index on (status, created_at)
- payment provider references and event IDs unique
- constraints for valid enum/status values
- indexes for both sides of blocks and connection pairs

## RLS policy intent
- Users can edit only their own profile and private preferences.
- Public profile reads expose only fields intended for discovery.
- Dating discovery returns only users who enabled dating and satisfy visibility rules.
- Only conversation members can read messages.
- A sender can create a message only as themselves and only when the conversation policy permits it.
- Users can create reports but cannot alter moderation outcomes.
- Users cannot write payment success status or premium entitlements directly.
- Only trusted server roles can process payment callbacks and privileged moderation actions.

## Explore Map schema additions

Add `user_presence`, restricted `user_locations`, and `location_visibility` (or equivalent fields/tables) as detailed in `docs/09-explore-map-architecture.md`. Enable PostGIS and spatial indexes for geographic queries. Precise coordinates must not be exposed by client-facing profile queries. Use UTC timestamps and an explicit stale-presence policy.
