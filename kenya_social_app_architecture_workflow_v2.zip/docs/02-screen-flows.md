# 02 — Screen Flows

## Primary navigation
Home · Discover · Create · Messages · Profile

## First-time user journey
1. Welcome: product explanation, sign up, sign in, Terms and Privacy Policy.
2. Age eligibility: adult-only notice and age assurance where appropriate.
3. Account: managed authentication.
4. Profile setup: display name, username, photo, bio, language and interests.
5. Intent selection: friendship, dating, social posts, or a combination.
6. Privacy setup: discovery visibility, profile visibility and location display.
7. Home: clear entry points to Friends, Dating and Social.
8. Discover: filters, cards/list, profile detail, connect/like actions.
9. Conversation: request state, chat, report, block and unmatch.
10. Settings: notifications, blocked users, privacy, export/delete account, support.

## Friendship flow
Discover Friends → View profile → Send request → Recipient accepts → Connection created → Chat available according to policy.

## Dating flow
Enable Dating mode → Complete dating profile/preferences → Discover opted-in profiles → Like → Mutual like → Match → Chat. Unmatch/block immediately prevents new contact.

## Social post flow
Create post → Choose audience (public/community) → Publish → View/comment → Report or delete. For anonymous notes, public UI does not expose author identity, while backend retains controlled internal reference for safety.

## Messaging flow
Open accepted connection or permitted message request → Send message → Server validates membership, account status, rate limits and blocks → Persist message → Notify recipient with privacy-safe payload.

## Account deletion flow
Settings → Delete account → Re-authenticate or confirm → Explain consequences and retention exceptions → Queue deletion/anonymization workflow → Revoke sessions → Confirm completion. Preserve only data that must be retained for legal, fraud or safety reasons, with documented basis and retention period.

## Admin flow
Moderator sign-in with MFA → Review report → Inspect minimum necessary context → Apply action → Record reason and audit event → Notify affected user where appropriate → Provide appeal/support route.

## Global Explore Map

- Open Explore from primary navigation.
- Search a town/city/country or pan the map.
- See privacy-safe markers for eligible online members who enabled map discovery.
- Tap a marker to preview a profile, then open it or use a permitted connection action.
- Allow users to disable map visibility and choose a manual location instead of GPS.
- Do not imply that selecting a city means the viewer is physically there.
