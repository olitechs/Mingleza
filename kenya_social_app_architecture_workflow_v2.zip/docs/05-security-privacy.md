# 05 — Security, Privacy and Moderation

## Threat model
Consider account takeover, scraping, harassment, impersonation, spam, payment callback spoofing, unauthorized message access, moderator misuse and exposure of precise location or intimate profile data.

## Required controls
1. Managed authentication; secure session storage; session revocation on logout, suspension and account deletion.
2. Row Level Security for all client-accessible tables, with automated tests for allowed and denied cases.
3. Rate limits for sign-up, likes, connection requests, messages, posts, notes, reports and password reset.
4. Server-side input validation, output encoding, content-length limits and safe handling of uploaded media.
5. Private storage buckets for sensitive uploads; file type/size checks and malware scanning where appropriate.
6. Secrets stored only in server-side environment/secret management.
7. Verified payment callbacks, idempotency and reconciliation.
8. Admin MFA, least privilege, moderator audit logs and restricted access to report evidence.
9. Backup and restore drills; dependency updates; monitoring for suspicious spikes.
10. Clear retention schedules and deletion workflows.

## 18+ access
- Make adult-only status explicit before registration.
- Do not rely solely on a self-declared age where risk or applicable law requires stronger assurance.
- Use proportionate verification and minimize retained identity data.
- Define procedures for suspected underage accounts, including restriction, review and deletion/escalation.

## Location
- Show broad labels such as town or city by default.
- Never expose precise coordinates publicly.
- Do not collect background location for the MVP.
- Make location optional and explain its purpose.

## Anonymous notes
- Hide the author's identity from normal public views.
- Retain controlled internal attribution for moderation and lawful obligations.
- Clearly explain that anonymous does not mean untraceable or exempt from platform rules.
- Rate-limit posting and reporting; detect spam and harassment.

## Blocking and reporting
- Block immediately prevents new direct contact and excludes the blocked user from discovery where feasible.
- Provide report categories for harassment, threats, impersonation, scams, sexual exploitation, spam and other violations.
- Preserve only the evidence needed for review, with access controls and retention rules.
- Provide moderator action logs and a user support/appeal process.

## Privacy and legal work
Before public launch, review Kenya's Data Protection Act and applicable ODPC registration obligations, cross-border data transfers, privacy notices, lawful bases, data subject rights and breach response. Obtain qualified legal advice for launch countries.
Review Google Play policies for user-generated content, dating/social functionality, user data, account deletion and payment requirements.

## Encryption claims
Use TLS in transit and provider-supported encryption at rest. Do not advertise end-to-end encryption unless a suitable protocol is implemented, tested and assessed. Never log message bodies, authentication tokens, payment secrets or unnecessary sensitive fields.

## Location discovery controls

Map visibility must be explained and revocable. Although the product wants to show online users with approximate locations, only users who have enabled/consented to map discovery should appear. Never expose precise GPS coordinates; use server-generated coarse display points/cells, rate limits, anti-enumeration safeguards, block filtering in both directions, account/age eligibility checks, and deletion/retention rules. Do not require background location for MVP. See `docs/09-explore-map-architecture.md`.
