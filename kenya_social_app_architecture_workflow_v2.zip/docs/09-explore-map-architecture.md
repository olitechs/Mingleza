# Explore Map: Global Online People Discovery

## Product decision

The app supports global map discovery: users can search any supported town, city, or country and see eligible online members whose approximate location falls within the selected area. The map is available on Android and the installable web app.

**Privacy interpretation:** the product request is to show online members with approximate locations. For a dating/friendship product, implement this as visible to other users only when the member has been clearly informed and has enabled/consented to map discovery. A user can turn visibility off at any time. Do not silently expose every account's location.

## User experience

1. Open Explore Map.
2. Search a town, city, region, or country, or pan/zoom the map.
3. The client sends the selected viewport or resolved geographic area to the trusted backend.
4. The backend returns a small, paginated set of eligible public discovery cards, not raw GPS coordinates.
5. Tap a map marker to see a profile preview: photo, display name, age where permitted, interests, friendship/dating intent, and online indicator.
6. Open the profile and use the relevant connection action: friend request, dating like, or message only where the app's connection rules permit.
7. Change the selected location to explore another city. Selecting a city is a search filter, not a claim that the viewer is physically there.

## Recommended technology

- Android: React Native + Expo + TypeScript.
- Web: Next.js + TypeScript PWA.
- Backend: Supabase Auth + PostgreSQL.
- Geographic queries: PostgreSQL with PostGIS.
- Presence: Supabase Realtime Presence for transient online state, supplemented by a server-managed heartbeat/session expiry if durable freshness is needed.
- Map SDK: compare Google Maps Platform and Mapbox for Android/web SDK fit, styling, geocoding, terms, and projected usage cost before choosing. Do not build the app's matching logic into the map vendor.
- Place search/geocoding: use the chosen provider's supported service or another provider with compatible licensing. Cache only where provider terms permit.

## High-level request flow

1. Authenticated client requests a map area, zoom level, selected place ID/bounds, and allowed filters.
2. Trusted API/Edge Function validates the session, query bounds, rate limits, account status, age eligibility, and discovery preferences.
3. Backend determines eligible users: active accounts, online within a defined freshness window, location-sharing enabled, not blocked in either direction, and eligible for the requested mode.
4. PostGIS performs the geographic query using an approximate public display point or a privacy-safe geographic cell.
5. Backend returns only necessary fields for map cards, capped and paginated. It never returns precise stored GPS coordinates.
6. Client clusters markers at low zoom and fetches again when the map area or selected location changes.
7. Connection actions are separately validated by the backend.

## Data model additions

Suggested tables/fields (adapt names to the existing schema):

### `user_presence`
- `user_id UUID PRIMARY KEY REFERENCES profiles(id)`
- `status` enum: `online`, `offline` (or derive status from active sessions)
- `last_seen_at TIMESTAMPTZ`
- `last_heartbeat_at TIMESTAMPTZ`
- `updated_at TIMESTAMPTZ`

Presence data should not be treated as an authoritative audit trail. A stale or disconnected session must expire.

### `user_locations` (restricted)
- `user_id UUID PRIMARY KEY REFERENCES profiles(id)`
- `location GEOGRAPHY(POINT, 4326)` or an appropriately protected geographic cell
- `accuracy_m INTEGER NULL`
- `source` enum such as `gps`, `manual_place`
- `updated_at TIMESTAMPTZ`
- `expires_at TIMESTAMPTZ NULL`

Only trusted server-side code and narrowly authorized database roles should access precise coordinates. Avoid exposing this table directly to client reads.

### `location_visibility`
- `user_id UUID PRIMARY KEY REFERENCES profiles(id)`
- `map_discovery_enabled BOOLEAN NOT NULL DEFAULT FALSE`
- `updated_at TIMESTAMPTZ`

Record the relevant consent/version and timestamp if required by the product's privacy notice and legal review.

### Place records (optional)
Store provider place IDs, normalized display names, country/region codes, and supported geographic boundaries when licensing allows. Do not assume every provider allows permanent caching of geocoding results.

## Geographic query behaviour

- Use PostGIS spatial indexes for scalable area/radius queries.
- For a selected city, resolve its supported boundary or an explicit radius policy; don't treat a city name alone as a reliable polygon.
- For a map viewport, validate maximum bounds and zoom; limit result count and page size.
- Use marker clustering or aggregated counts at low zoom, and reveal individual profile cards only at a suitable zoom level.
- Apply rate limits and anti-enumeration controls to prevent users from scraping the online population city by city.
- Keep result ranking simple at MVP: geographic eligibility, online freshness, profile completeness, and user preferences. Avoid claiming that results are a perfect list of everyone online.

## Approximate location design

- Never return raw device GPS coordinates to another user.
- Generate a separate display point or privacy-safe geographic cell on the server; do not simply expose the stored point with a different label.
- Apply a configurable minimum spatial coarseness and consider jitter or grid/cell-based display. Ensure repeated queries cannot average away the privacy protection.
- Suppress markers when a location is too uncertain, stale, or too close to a sensitive/private context.
- Do not show a home/workplace pin or exact distance if it could reveal precise whereabouts.
- Provide manual city selection as an alternative to GPS.
- Do not require background location for MVP. Update location only while the app is in use and the user has granted permission, or use a manually selected city.
- Avoid collecting location history unless there is a documented product need and retention policy.

## Online presence rules

- Presence is transient; database records may store last-seen timestamps, but a stale session should not remain online indefinitely.
- Define an explicit freshness threshold and test sleep, app backgrounding, force-close, network loss, logout, and expired tokens.
- Avoid high-frequency GPS or presence writes. Refresh results on map open, place/viewport changes, and deliberate refresh; add realtime updates only when needed.
- Never use Realtime Presence alone as authorization. The backend must re-check account state, blocks, visibility, and discovery eligibility.

## API contract (illustrative)

`GET /api/discovery/map?placeId=...&bbox=west,south,east,north&mode=friends`

Return only public map cards, for example:
- `profileId`
- `displayName`
- `avatarUrl`
- `ageDisplay` (if product policy permits)
- `intent`
- `interestPreview`
- `online: true`
- `displayLocation` (coarse label or privacy-safe display point)
- `nextCursor` (optional)

Never include `preciseLatitude`, `preciseLongitude`, phone number, email, private preferences, or internal moderation data.

`POST /api/location/update` accepts a validated location update only when permitted by platform permissions and the user's settings. Store precise input only if genuinely needed, restrict access, and define expiry/retention.

`PATCH /api/location-visibility` updates map visibility and consent.

These are illustrative routes, not implemented endpoints.

## Security and abuse prevention

- RLS enabled on every client-accessible table.
- Precise location table has no direct public/client SELECT policy.
- All map results go through trusted server-side authorization.
- Exclude blocked accounts both ways, suspended/banned accounts, ineligible accounts, and users who disabled map discovery.
- Rate-limit map queries, place search, profile opens, and location updates.
- Limit page size and prevent arbitrary high-resolution global scraping.
- Keep audit events for sensitive administrative access, without logging raw GPS unnecessarily.
- Add tests for RLS bypass, IDOR, block enforcement, disabled visibility, stale presence, and coordinate leakage.
- Account deletion removes or de-identifies location and presence data under the retention policy.

## Cost and operations

- Compare Google Maps Platform and Mapbox on expected Android map loads, web map loads, geocoding/autocomplete, styling needs, terms, and usage-based costs.
- Create restricted API keys per platform and apply quotas/billing alerts.
- Do not put server secrets in mobile/web client bundles. Use platform-restricted public map keys only as allowed by provider documentation.
- Avoid routing/directions APIs unless a later feature needs them.
- Monitor map loads, place-search requests, map query volume, database query latency, result counts, and abuse signals.

## MVP acceptance criteria

- A user can search supported cities/towns/countries worldwide.
- Map results include only active, eligible users who are online within the defined freshness threshold and have enabled map discovery.
- A user can disable map visibility and disappear from discovery promptly.
- A tap opens a profile preview and only permitted connection actions.
- Blocks are enforced in both directions.
- No client response contains stored precise GPS coordinates.
- Map requests are bounded, paginated/rate-limited, and tested against scraping.
- Location can be supplied through a manually selected place without granting GPS.
- Map SDK usage is monitored and budget alerts are configured.
