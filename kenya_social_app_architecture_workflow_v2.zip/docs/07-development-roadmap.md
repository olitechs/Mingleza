# 07 — Development Roadmap

Time estimates assume a focused scope and substantial weekly development time; a solo beginner may need longer.

## Phase 1 — Foundation and design (Week 1)
- Confirm working brand, repository and code conventions.
- Create Expo app, Next.js PWA and shared packages.
- Create separate local, staging and production environments.
- Define design tokens, navigation and initial screen prototypes.
- Create initial Supabase project and migration workflow.
**Acceptance:** both clients run; secrets are not committed; CI checks pass.

## Phase 2 — Accounts and profiles (Weeks 2–3)
- Configure managed authentication.
- Build age gate and age-assurance approach.
- Create profile and preferences tables.
- Implement profile editing, interests and visibility controls.
- Add initial RLS policies and policy tests.
**Acceptance:** user A cannot edit or access user B's private profile/preferences.

## Phase 3 — Social and connection engine (Weeks 4–5)
- Build friends discovery and requests.
- Build opt-in dating discovery, likes and mutual matches.
- Build posts, comments and communities.
- Add one-to-one messaging and message request rules.
- Add block/unmatch behavior.
**Acceptance:** connection and messaging flows work across both clients; blocks are enforced server-side.

## Phase 4 — Safety and monetization (Weeks 6–7)
- Implement report queue and moderation actions.
- Add rate limits and spam controls.
- Add account deletion workflow.
- Implement payment adapter and sandbox callback verification.
- Add premium entitlement and purchase history.
**Acceptance:** invalid payment callbacks cannot grant premium; moderation actions are audited.

## Phase 5 — QA and controlled launch (Weeks 8–9)
- Test supported Android versions and low-end devices.
- Test slow networks, session expiry, offline/error states and accessibility.
- Test RLS, abuse scenarios, deletion and backup restoration.
- Finalize privacy policy, terms, community guidelines and store disclosures.
- Prepare support operations and release monitoring.
**Acceptance:** no known critical security issue; payment reconciliation works; moderation response process exists; store review requirements are met.

## Definition of done for every feature
- UI states: loading, empty, success, error and retry.
- Server-side validation and authorization.
- RLS tests for allowed and denied cases.
- Analytics events avoid private content.
- Accessibility and localization review.
- Automated tests and documented deployment steps.

## Explore Map workstream

Add a map prototype and place search after the shared account/profile foundation. Then implement PostGIS queries, presence freshness, privacy-safe markers, profile previews, and abuse prevention. Do not launch map discovery until consent/opt-out, block filtering, rate limiting, coordinate-leakage tests, and provider usage alerts pass. Detailed acceptance criteria are in `docs/09-explore-map-architecture.md`.
