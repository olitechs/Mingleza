# 01 — Product Requirements

## Product vision
A Kenya-first social app for adults 18+ that supports friendship, opt-in dating, and general social networking. The same account and backend power the Android app and installable web app.

## Target users
- Adults in Kenya at launch
- Users seeking platonic friendships
- Adults who explicitly opt into dating
- Users interested in public posts, shared interests and communities
- Future users across other African and European markets

## MVP features

### Accounts and profiles
- Registration and sign-in through a managed auth provider
- 18+ eligibility gate and proportionate age-assurance process
- Username, display name, profile photo, bio, language and interests
- Separate public profile and private settings
- Account status, privacy preferences and account deletion request

### Discovery
- Friendship discovery
- Dating discovery only for users who opt in
- Filters based on supported preferences and interests
- Broad location labels only by default; no public precise coordinates
- User block list excluded from search and recommendations

### Connections and dating
- Friendship request, accept, reject and cancel
- Dating like and mutual match
- Unmatch and block
- Prevent duplicate or contradictory active relationships through database constraints and server logic

### Social
- Public or community-scoped posts
- Comments and basic reactions (optional for MVP)
- Interest-based communities
- Anonymous notes with clear limits: identity hidden from ordinary viewers, not guaranteed anonymous from platform operators or lawful processes
- Report content and user accounts

### Messaging
- One-to-one text messaging
- Message request / accepted connection policy
- Conversation membership authorization
- Mute, block, report and message-rate limits
- Push notifications that do not reveal sensitive content by default

### Admin and safety
- Moderation queue and report status
- Suspend, restrict and reinstate account actions
- Audit log for sensitive moderator actions
- Basic metrics that do not collect private message contents

### Monetization
- Free baseline social features
- Premium entitlement and expiry
- Optional profile/post boosts, clearly labelled
- Payment ledger and verified callbacks
- Business promotions deferred until the core community has traction

## Non-goals for MVP
- Voice/video calls
- Livestreaming
- Real-time location sharing
- Virtual gifts and coins
- AI companion
- Complex recommendation ML
- Multi-country payment support at launch

## Product principles
1. Friendship and dating are distinct modes.
2. Dating is opt-in and can be disabled.
3. Blocking and reporting remain free.
4. Collect only data needed for product functionality and safety.
5. Do not claim end-to-end encryption unless it is implemented and assessed.
6. Make weak-network and low-end Android support a first-class requirement.
